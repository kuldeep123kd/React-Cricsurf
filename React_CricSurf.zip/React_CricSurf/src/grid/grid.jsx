import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Featnews from '../Components/featurenews/featnews'
import Teamrank from '../Components/teamrank/team'
import Livescore from '../Components/livescore/livescore'
import Post from '../Components/post/post'
import Newsletter from '../Components/newsletter/newsletter'
import Toppost from '../Components/toppost/toppost'
import './grid.css'


const useStyles = makeStyles(theme => ({
    container: {
      display: 'grid',
      gridTemplateColumns: 'repeat(12, 1fr)',
      gridGap: theme.spacing(3),
    },
    paper: {
      padding: theme.spacing(1),
      textAlign: 'center',
      color: theme.palette.text.secondary,
      whiteSpace: 'nowrap',
      marginBottom: theme.spacing(1),
    },
  }));
  export default function CSSGrid() {
    const classes = useStyles();
  
    return (
      <div className="grd">
        <Typography variant="subtitle1" gutterBottom>
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={8}>
              <div className="posts"><Post/></div>
          </Grid>
          <Grid item xs={4}>
              <div className="grid_content">
                  <Livescore/>
                  <Featnews/>
                  <Toppost/>
                  <Teamrank/>
              </div>  
          </Grid>
          <div className="newslet"><Newsletter/></div>
        </Grid>
      </div>
    );
  }