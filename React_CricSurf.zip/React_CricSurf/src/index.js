import React, { Component } from 'react'
import ReactDOM from 'react-dom';
import './index.css';
import Navbar from './Components/Navbar/Navbar'
import Newsfeed from './Components/Newsfeed/newsfeed'
import Featnews from './Components/featurenews/featnews'
import Carousel from './Components/carousel/carousel_blog'
import Teamrank from './Components/teamrank/team'
import Livescore from './Components/livescore/livescore'
import Post from './Components/post/post'
import Newsletter from './Components/newsletter/newsletter'
import Toppost from './Components/toppost/toppost'
import Footer from './Components/footer/footer'
import Grid from './grid/grid'
  

const Body = ()=>{

  return(<React.Fragment>
    <Navbar/>
    <Newsfeed/>
    <Carousel/>
    <Grid/>
    <Footer/>
  </React.Fragment>
  )

}


ReactDOM.render(
  <Body/>,
  document.getElementById('root')
);