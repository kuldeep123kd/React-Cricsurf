import logo1 from './virat.jpg'
import logo2 from './pic1.jpg'
import logo3 from './pic2.jpg'

const data = [
   
    {
        "id": 1,
        "post_heading": "heading 1",
        "post_imgUrl": "./virat.jpg",
        "full_posturl": "#"
    },
    {
        "id": 2,
        "post_heading": "heading 2",
        "post_imgUrl": "./pic1.jpg",
        "full_posturl": "#"
    },   {
        "id": 3,
        "post_heading": "heading 3",
        "post_imgUrl": "./pic2.jpg",
        "full_posturl": "#"
    }
]
const imgarray=[logo1, logo2, logo3];
export default  [imgarray, data];